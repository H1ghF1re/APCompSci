public class HelloWorld
{
   public static void main ( String cheese[] )
   {
       System.out.println( "Hello World!" );
       
    } //end main method
    
}  //end class
